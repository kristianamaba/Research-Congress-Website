<?php

class Pages extends CI_Controller{
	public function __construct(){
		parent::__construct();

		// Load Model
		$this->load->model('Main_model');

		// Load base_url
		$this->load->helper('url');
	}
  
	function view($page = 'index')
	{
		
		if( !file_exists('application/views/pages/'.$page.'.php'))
		{
			show_404();
		}
		else{
			$data["test"] = "asdasd";
			$this->load->view('pages/'.$page, $data);
		}
		
	}
	
}


?>