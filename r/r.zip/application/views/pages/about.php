<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
	<title>X-DATA - About us</title>

	<!-- Fonts -->
	<link href="//fonts.googleapis.com/css?family=Open+Sans:400,600,700%7CRaleway:400,700" rel="stylesheet">
	<!-- Favicon -->
	<link rel="icon" type="image/ico" href="assets/img/favicon.ico">
	<!-- Bootstrap -->
	<link href="assets/css/bootstrap.min.css" rel="stylesheet">
	<!-- Font Awesome -->
	<link href="assets/css/font-awesome.min.css" rel="stylesheet">
	<!-- Owl Carousel -->
	<link rel="stylesheet" href="assets/css/owl.carousel.min.css">
	<link rel="stylesheet" href="assets/css/owl.theme.default.min.css">
	<!-- Custom Style -->
	<link href="assets/css/style.css" rel="stylesheet">
	<link href="assets/css/default_theme.css" rel="stylesheet">
	<!-- Responsive Style -->
	<link href="assets/css/responsive.css" rel="stylesheet">

	<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
	<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
	<!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>

<body>

		<div class="layout-width">
		<?php $this->load->view('sub-page/header'); ?>
		

		<!-- About us -->
		<section class="about-us">
			<div class="container">
				<!-- Title -->
				<div class="sec-title">
					<h2>Our Aim & Scope</h2>
					<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
				</div>
				<!-- Year -->
				<div class="block-comp">
					<span>VISION</span>
					<p>We envision the University of Makati as the primary instrument where University education and Industry training programs interface to mold Makati youth into productive citizens and IT-enabled professionals who are exposed to the cutting edge of technology in their areas of specialization. The University shall be the final stage of Makati City's integrated primary level to university educational system that allows its less privileged citizens to compete for high paying job opportunities in its business and industries.</p>
				</div>
				<!-- Support -->
				<div class="block-comp">
					<span>MISSION</span>
					<p>To achieve our vision, University of Makati shall mold highly competent professionals and skilled workers from the children of poor Makati residents while inculcating in them good moral values and desirable personality development by offering baccalaureate degree, graduate degree, and non-degree programs with parallel on campus social, cultural, sports and other co-curricular activities.</p>
				</div>
			</div>
		</section>


		<div class="clearfix"></div>

		<?php $this->load->view('sub-page/footer'); ?>
	</div>

	<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
	<script src="assets/js/jquery-2.2.4.min.js"></script>
	<!-- Include all compiled plugins (below), or include individual files as needed -->
	<script src="assets/js/popper.min.js"></script>
	<script src="assets/js/bootstrap.min.js"></script>
	<!-- Owl Carousel -->
	<script src="assets/js/owl.carousel.min.js"></script>
	<!-- Google Map -->
	<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCxKD5cjuV3XpEdKILj0a_XnW4GIfiIqD4"></script>
	<script src="assets/js/map.js"></script>
	<!-- Plugins -->
	<script src="assets/js/plugins.js"></script>

</body>

</html>
