<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
	<title>X-DATA - Contact</title>

	<!-- Fonts -->
	<link href="//fonts.googleapis.com/css?family=Open+Sans:400,600,700%7CRaleway:400,700" rel="stylesheet">
	<!-- Favicon -->
	<link rel="icon" type="image/ico" href="assets/img/favicon.ico">
	<!-- Bootstrap -->
	<link href="assets/css/bootstrap.min.css" rel="stylesheet">
	<!-- Font Awesome -->
	<link href="assets/css/font-awesome.min.css" rel="stylesheet">
	<!-- Owl Carousel -->
	<link rel="stylesheet" href="assets/css/owl.carousel.min.css">
	<link rel="stylesheet" href="assets/css/owl.theme.default.min.css">
	<!-- Custom Style -->
	<link href="assets/css/style.css" rel="stylesheet">
	<link href="assets/css/default_theme.css" rel="stylesheet">
	<!-- Responsive Style -->
	<link href="assets/css/responsive.css" rel="stylesheet">

	<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
	<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
	<!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>

<body>

		<div class="layout-width">
		<?php $this->load->view('sub-page/header'); ?>

		

		

		<!-- Contact Form -->
		<div class="c-form">
			<div class="offset-lg-3 col-lg-6">
				<div class="sec-title">
					<h2>Submit Research</h2>
					<p>With/Without an Account.</p>
				</div>
				<!-- Form -->
				<form class="contact-us">
					<div class="field-form">
						<!-- UserName -->
						<input type="text" placeholder="Your Name" class="user-n half">
					</div>
					<div class="field-form">
						<!-- Mail -->
						<input type="email" placeholder="Your Email" class="user-n half">
					</div>
					<div class="field-form">
						<!-- Phone -->
						<input type="phone" placeholder="Your Phone Number" class="user-n half">
					</div>
					<div class="field-form">
						<!-- Subject -->
						<input type="text" placeholder="Subject" class="user-n f-wid">
					</div>
					<div class="field-form">
						<!-- Message -->
						<textarea class="user-n f-wid" name="Message" id="msg-c">Message</textarea>
					</div>
					<!-- Send Btn -->
					<input type="submit" class="user-sub" value="Submit Research">
				</form>
			</div>
		</div>

		<div class="clearfix"></div>
		<?php $this->load->view('sub-page/footer'); ?>
	</div>

	<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
	<script src="assets/js/jquery-2.2.4.min.js"></script>
	<!-- Include all compiled plugins (below), or include individual files as needed -->
	<script src="assets/js/popper.min.js"></script>
	<script src="assets/js/bootstrap.min.js"></script>
	<!-- Owl Carousel -->
	<script src="assets/js/owl.carousel.min.js"></script>
	<!-- Google Map -->
	<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCxKD5cjuV3XpEdKILj0a_XnW4GIfiIqD4"></script>
	<script src="assets/js/map.js"></script>
	<!-- Plugins -->
	<script src="assets/js/plugins.js"></script>

</body>

</html>
