<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
	<title>X-DATA - Short Codes</title>

	<!-- Fonts -->
	<link href="//fonts.googleapis.com/css?family=Open+Sans:400,600,700%7CRaleway:400,700" rel="stylesheet">
	<!-- Favicon -->
	<link rel="icon" type="image/ico" href="assets/img/favicon.ico">
	<!-- Bootstrap -->
	<link href="assets/css/bootstrap.min.css" rel="stylesheet">
	<!-- Font Awesome -->
	<link href="assets/css/font-awesome.min.css" rel="stylesheet">
	<!-- Owl Carousel -->
	<link rel="stylesheet" href="assets/css/owl.carousel.min.css">
	<link rel="stylesheet" href="assets/css/owl.theme.default.min.css">
	<!-- Custom Style -->
	<link href="assets/css/style.css" rel="stylesheet">
	<link href="assets/css/default_theme.css" rel="stylesheet">
	<!-- Responsive Style -->
	<link href="assets/css/responsive.css" rel="stylesheet">

	<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
	<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
	<!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>

<body>

		<div class="layout-width">
		<?php $this->load->view('sub-page/header'); ?>
		<div class="clearfix"></div>

		<div class="container">
			<div class="short-code">
				<div class="row">
					<!-- Nav -->
					<div class="col-lg-3">
						<nav class="code-nav">
							<ul>
								<li>
									<span class="fa fa-columns s-code"></span>
									<a href="#columns-c">Page Cloumns</a>
								</li>
								<li>
									<span class="fa fa-text-width s-code"></span>
									<a href="#typo">Typography</a>
								</li>
								<li>
									<span class="fa fa-text-height s-code"></span>
									<a href="#t-styles">Title Styles</a>
								</li>
								<li>
									<span class="fa fa-commenting s-code"></span>
									<a href="#alerts">Boxes Alert</a>
								</li>
								<li>
									<span class="fa fa-reorder s-code"></span>
									<a href="#l-btns">List of Buttons</a>
								</li>
								<li>
									<span class="fa fa-font-awesome s-code"></span>
									<a href="#f-icons">Font Icons</a>
								</li>
								<li>
									<span class="fa fa-image s-code"></span>
									<a href="#i-frame">Image Frames</a>
								</li>
								<li>
									<span class="fa fa-location-arrow s-code"></span>
									<a href="#p-tables">Pricing Tables</a>
								</li>
								<li>
									<span class="fa fa-plus-circle s-code"></span>
									<a href="#acc-tog">Accordion &amp; Toggle</a>
								</li>
							</ul>
						</nav>
					</div>

					<!-- Components -->
					<div class="col-lg-9">

						<!-- Page Cloumns -->
						<div id="columns-c" class="code-box">
							<div class="block-code">
								<!-- Col-lg-6 -->
								<div class="row">
									<div class="blocks-col">
										<div class="col-lg-6 col-sm-6 col-xs-6">
											<div class="title-block-code">6 Columns</div>
											<p class="text-block-code">
												The standard chunk of Lorem Ipsum used since the 1500s is reproduced below for those interested. Sections 1.10.32 and 1.10.33
												from "de Finibus Bonorum et Malorum" by Cicero are also reproduced in their exact original form.
											</p>
										</div>
										<div class="col-lg-6 col-sm-6 col-xs-6">
											<div class="title-block-code">6 Columns</div>
											<p class="text-block-code">
												The standard chunk of Lorem Ipsum used since the 1500s is reproduced below for those interested. Sections 1.10.32 and 1.10.33
												from "de Finibus Bonorum et Malorum" by Cicero are also reproduced in their exact original form.
											</p>
										</div>
									</div>
								</div>
								<hr>
								<!-- Col-lg-4 -->
								<div class="row">
									<div class="blocks-col">
										<div class="col-lg-4 col-sm-4 col-xs-4">
											<div class="title-block-code">4 Columns</div>
											<p class="text-block-code">
												The standard chunk of Lorem Ipsum used since the 1500s is reproduced below for those interested. Sections 1.10.32 and 1.10.33
												from "de Finibus Bonorum et Malorum"
											</p>
										</div>
										<div class="col-lg-4 col-sm-4 col-xs-4">
											<div class="title-block-code">4 Columns</div>
											<p class="text-block-code">
												The standard chunk of Lorem Ipsum used since the 1500s is reproduced below for those interested. Sections 1.10.32 and 1.10.33
												from "de Finibus Bonorum et Malorum"
											</p>
										</div>
										<div class="col-lg-4 col-sm-4 col-xs-4">
											<div class="title-block-code">4 Columns</div>
											<p class="text-block-code">
												The standard chunk of Lorem Ipsum used since the 1500s is reproduced below for those interested. Sections 1.10.32 and 1.10.33
												from "de Finibus Bonorum et Malorum"
											</p>
										</div>
									</div>
								</div>
								<hr>
								<!-- Col-lg-3 -->
								<div class="row">
									<div class="blocks-col">
										<div class="col-lg-3 col-sm-3 col-xs-3">
											<div class="title-block-code">3 Columns</div>
											<p class="text-block-code">
												The standard chunk of Lorem Ipsum used since the 1500s is reproduced below for those interested.
											</p>
										</div>
										<div class="col-lg-3 col-sm-3 col-xs-3">
											<div class="title-block-code">3 Columns</div>
											<p class="text-block-code">
												The standard chunk of Lorem Ipsum used since the 1500s is reproduced below for those interested.
											</p>
										</div>
										<div class="col-lg-3 col-sm-3 col-xs-3">
											<div class="title-block-code">3 Columns</div>
											<p class="text-block-code">
												The standard chunk of Lorem Ipsum used since the 1500s is reproduced below for those interested.
											</p>
										</div>
										<div class="col-lg-3 col-sm-3 col-xs-3">
											<div class="title-block-code">3 Columns</div>
											<p class="text-block-code">
												The standard chunk of Lorem Ipsum used since the 1500s is reproduced below for those interested.
											</p>
										</div>
									</div>
								</div>
							</div>
						</div>

						<!-- Typography -->
						<div id="typo" class="code-box">
							<div class="block-code">
								<div class="heads">
									<h1>h1. X-Data heading</h1>
									<hr>
									<h2>h2. X-Data heading</h2>
									<hr>
									<h3>h3. X-Data heading</h3>
									<hr>
									<h4>h4. X-Data heading</h4>
									<hr>
									<h5>h5. X-Data heading</h5>
									<hr>
									<h6>h6. X-Data heading</h6>
								</div>
							</div>
						</div>

						<!-- Title Styles -->
						<div id="t-styles" class="code-box">
							<div class="block-code">
								<div class="t-sty-a">
									<h2>Featured Plans</h2>
									<p>The standard chunk of Lorem Ipsum used since the 1500s is reproduced below for those interested.</p>
								</div>
								<hr>
								<div class="t-sty-a colored">
									<h2>Featured Plans</h2>
									<p>The standard chunk of Lorem Ipsum used since the 1500s is reproduced below for those interested.</p>
								</div>
								<hr>
								<div class="t-sty-a">
									<h2>Our
										<span class="bg-colored">Featured</span> Plans</h2>
									<p>The standard chunk of Lorem Ipsum used since the 1500s is reproduced below for those interested.</p>
								</div>
								<hr>
								<div class="t-sty-a">
									<h2>Our
										<span class="bg-cys">Featured</span> Plans</h2>
									<p>The standard chunk of Lorem Ipsum used since the 1500s is reproduced below for those interested.</p>
								</div>
								<hr>
								<div class="row">
									<div class="col-lg-4">
										<div class="t-sty-a blocks-ti">
											<i class="fa fa-rocket short-sq"></i>
											<h2>Featured Plans</h2>
											<p>The standard chunk of Lorem Ipsum used since the 1500s.</p>
										</div>
									</div>
									<div class="col-lg-4">
										<div class="t-sty-a blocks-ti">
											<i class="fa fa-rocket short-circ"></i>
											<h2>Featured Plans</h2>
											<p>The standard chunk of Lorem Ipsum used since the 1500s.</p>
										</div>
									</div>
									<div class="col-lg-4">
										<div class="t-sty-a blocks-ti">
											<i class="fa fa-rocket short-rad"></i>
											<h2>Featured Plans</h2>
											<p>The standard chunk of Lorem Ipsum used since the 1500s.</p>
										</div>
									</div>
								</div>
								<hr>
								<div class="row">
									<div class="col-lg-4">
										<div class="t-sty-a blocks-ti">
											<i class="fa fa-rocket short-sq bgz"></i>
											<h2>Featured Plans</h2>
											<p>The standard chunk of Lorem Ipsum used since the 1500s.</p>
										</div>
									</div>
									<div class="col-lg-4">
										<div class="t-sty-a blocks-ti">
											<i class="fa fa-rocket short-circ bgz"></i>
											<h2>Featured Plans</h2>
											<p>The standard chunk of Lorem Ipsum used since the 1500s.</p>
										</div>
									</div>
									<div class="col-lg-4">
										<div class="t-sty-a blocks-ti">
											<i class="fa fa-rocket short-rad bgz"></i>
											<h2>Featured Plans</h2>
											<p>The standard chunk of Lorem Ipsum used since the 1500s.</p>
										</div>
									</div>
								</div>
							</div>
						</div>

						<!-- Alerts -->
						<div id="alerts" class="code-box">
							<div class="block-code">
								<div class="row">
									<div class="col-lg-6">
										<div class="alert alert-success" role="alert">Well done! You successfully read this important alert message.</div>
									</div>
									<div class="col-lg-6">
										<div class="alert alert-success" role="alert">
											Well done! You
											<a href="#" class="alert-link">successfully</a> read this important alert message.
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-lg-6">
										<div class="alert alert-info" role="alert">Well done! You successfully read this important alert message.</div>
									</div>
									<div class="col-lg-6">
										<div class="alert alert-info" role="alert">
											Well done! You
											<a href="#" class="alert-link">successfully</a> read this important alert message.
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-lg-6">
										<div class="alert alert-warning" role="alert">Well done! You successfully read this important alert message.</div>
									</div>
									<div class="col-lg-6">
										<div class="alert alert-warning" role="alert">
											Well done! You
											<a href="#" class="alert-link">successfully</a> read this important alert message.
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-lg-6">
										<div class="alert alert-danger" role="alert">Well done! You successfully read this important alert message.</div>
									</div>
									<div class="col-lg-6">
										<div class="alert alert-danger" role="alert">
											Well done! You
											<a href="#" class="alert-link">successfully</a> read this important alert message.
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-lg-12">
										<div class="x-data-alert">
											<span class="fa fa-star x-icon"></span>
											<p>Well done! You successfully read this important alert message.</p>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-lg-12">
										<div class="x-data-alert bg-col">
											<span class="fa fa-star bg-col x-icon"></span>
											<p>Well done! You successfully read this important alert message.</p>
										</div>
									</div>
								</div>
							</div>
						</div>

						<!-- Buttons -->
						<div id="l-btns" class="code-box">
							<div class="block-code">
								<!-- Standard button -->
								<button type="button" class="btn btn-default">Default</button>
								<!-- Provides extra visual weight and identifies the primary action in a set of buttons -->
								<button type="button" class="btn btn-primary">Primary</button>
								<!-- Indicates a successful or positive action -->
								<button type="button" class="btn btn-success">Success</button>
								<!-- Contextual button for informational alert messages -->
								<button type="button" class="btn btn-info">Info</button>
								<!-- Indicates caution should be taken with this action -->
								<button type="button" class="btn btn-warning">Warning</button>
								<!-- Indicates a dangerous or potentially negative action -->
								<button type="button" class="btn btn-danger">Danger</button>
								<hr>
								<!-- Small -->
								<div class="small-btn">
									<button class="bg-btn">X-Data</button>
									<button class="bg-btn-o-brd">X-Data</button>
									<button class="bg-btn-b-brd">X-Data</button>
									<button class="bg-btn-icon">
										<span class="fa fa-user s-btn-c"></span>X-Data</button>
									<button class="bg-btn-o-brd">
										<span class="fa fa-user s-btn-c"></span>X-Data</button>
									<button class="bg-btn-b-brd">
										<span class="fa fa-user s-btn-c"></span>X-Data</button>
									<button class="bg-btn-cys">X-Data</button>
									<button class="bg-btn-cys-brd">X-Data</button>
								</div>
								<hr>
								<!-- Medium -->
								<div class="small-btn">
									<button class="bg-btn md">X-Data</button>
									<button class="bg-btn-o-brd md">X-Data</button>
									<button class="bg-btn-b-brd md">X-Data</button>
									<button class="bg-btn-icon md">
										<span class="fa fa-user s-btn-c"></span>X-Data</button>
									<button class="bg-btn-o-brd md">
										<span class="fa fa-user s-btn-c"></span>X-Data</button>
									<button class="bg-btn-b-brd md">
										<span class="fa fa-user s-btn-c"></span>X-Data</button>
									<button class="bg-btn-cys md">X-Data</button>
									<button class="bg-btn-cys-brd md">X-Data</button>
								</div>
								<hr>
								<!-- Medium -->
								<div class="small-btn">
									<button class="bg-btn lg">X-Data</button>
									<button class="bg-btn-o-brd lg">X-Data</button>
									<button class="bg-btn-b-brd lg">X-Data</button>
									<button class="bg-btn-icon lg">
										<span class="fa fa-user s-btn-c"></span>X-Data</button>
									<button class="bg-btn-o-brd lg">
										<span class="fa fa-user s-btn-c"></span>X-Data</button>
									<button class="bg-btn-b-brd lg">
										<span class="fa fa-user s-btn-c"></span>X-Data</button>
									<button class="bg-btn-cys lg">X-Data</button>
									<button class="bg-btn-cys-brd lg">X-Data</button>
								</div>
							</div>
						</div>

						<!-- Font Icons -->
						<div id="f-icons" class="code-box">
							<div class="block-code">
								<h1 class="title-font">
									<span class="bg-cys">V1</span>Every Font Awesome 4.7.0 Icon, CSS Class, &amp; Unicode</h1>
								<hr>
								<div class="row">
									<div class="col-lg-3">
										<i class="fa fa-camera-retro fa-lg"></i> fa-lg
										<br>
										<i class="fa fa-camera-retro fa-2x"></i> fa-2x
										<br>
										<i class="fa fa-camera-retro fa-3x"></i> fa-3x
										<br>
										<i class="fa fa-camera-retro fa-4x"></i> fa-4x
										<br>
										<i class="fa fa-camera-retro fa-5x"></i> fa-5x
									</div>
									<div class="col-lg-5">
										<i class="fa fa-spinner fa-spin fa-3x fa-fw"></i>
										<span class="sr-only">Loading...</span>
										<i class="fa fa-circle-o-notch fa-spin fa-3x fa-fw"></i>
										<span class="sr-only">Loading...</span>
										<i class="fa fa-refresh fa-spin fa-3x fa-fw"></i>
										<span class="sr-only">Loading...</span>
										<i class="fa fa-cog fa-spin fa-3x fa-fw"></i>
										<span class="sr-only">Loading...</span>
										<hr>
										<i class="fa fa-shield"></i> normal
										<br>
										<i class="fa fa-shield fa-rotate-90"></i> fa-rotate-90
										<br>
										<i class="fa fa-shield fa-rotate-180"></i> fa-rotate-180
										<br>
										<i class="fa fa-shield fa-rotate-270"></i> fa-rotate-270
										<br>
										<i class="fa fa-shield fa-flip-horizontal"></i> fa-flip-horizontal
										<br>
									</div>
									<div class="col-lg-4">
										<span class="fa-stack fa-lg">
											<i class="fa fa-square-o fa-stack-2x"></i>
											<i class="fa fa-twitter fa-stack-1x"></i>
										</span> fa-twitter on fa-square-o
										<br>
										<span class="fa-stack fa-lg">
											<i class="fa fa-circle fa-stack-2x"></i>
											<i class="fa fa-flag fa-stack-1x fa-inverse"></i>
										</span> fa-flag on fa-circle
										<br>
										<span class="fa-stack fa-lg">
											<i class="fa fa-square fa-stack-2x"></i>
											<i class="fa fa-terminal fa-stack-1x fa-inverse"></i>
										</span> fa-terminal on fa-square
										<br>
										<span class="fa-stack fa-lg">
											<i class="fa fa-camera fa-stack-1x"></i>
											<i class="fa fa-ban fa-stack-2x text-danger"></i>
										</span> fa-ban on fa-camera
									</div>
								</div>
								<hr>
								<!-- Icons set -->
								<div class="row">
									<div class="col-md-4 col-sm-6 col-lg-3">
										<i class="fa fa-fw fa-500px" aria-hidden="true" title="Copy to use 500px"></i> fa-500px
									</div>
									<div class="col-md-4 col-sm-6 col-lg-3">
										<i class="fa fa-fw fa-address-book" aria-hidden="true" title="Copy to use address-book"></i> fa-address-book
									</div>
									<div class="col-md-4 col-sm-6 col-lg-3">
										<i class="fa fa-fw fa-address-book-o" aria-hidden="true" title="Copy to use address-book-o"></i> fa-address-book-o
									</div>
									<div class="col-md-4 col-sm-6 col-lg-3">
										<i class="fa fa-fw fa-address-card" aria-hidden="true" title="Copy to use address-card"></i> fa-address-card
									</div>
									<div class="col-md-4 col-sm-6 col-lg-3">
										<i class="fa fa-fw fa-address-card-o" aria-hidden="true" title="Copy to use address-card-o"></i> fa-address-card-o
									</div>
									<div class="col-md-4 col-sm-6 col-lg-3">
										<i class="fa fa-fw fa-adjust" aria-hidden="true" title="Copy to use adjust"></i> fa-adjust
									</div>
									<div class="col-md-4 col-sm-6 col-lg-3">
										<i class="fa fa-fw fa-adn" aria-hidden="true" title="Copy to use adn"></i> fa-adn
									</div>
									<div class="col-md-4 col-sm-6 col-lg-3">
										<i class="fa fa-fw fa-align-center" aria-hidden="true" title="Copy to use align-center"></i> fa-align-center
									</div>
									<div class="col-md-4 col-sm-6 col-lg-3">
										<i class="fa fa-fw fa-align-justify" aria-hidden="true" title="Copy to use align-justify"></i> fa-align-justify
									</div>
									<div class="col-md-4 col-sm-6 col-lg-3">
										<i class="fa fa-fw fa-align-left" aria-hidden="true" title="Copy to use align-left"></i> fa-align-left
									</div>
									<div class="col-md-4 col-sm-6 col-lg-3">
										<i class="fa fa-fw fa-align-right" aria-hidden="true" title="Copy to use align-right"></i> fa-align-right
									</div>
									<div class="col-md-4 col-sm-6 col-lg-3">
										<i class="fa fa-fw fa-amazon" aria-hidden="true" title="Copy to use amazon"></i> fa-amazon
									</div>
									<div class="col-md-4 col-sm-6 col-lg-3">
										<i class="fa fa-fw fa-ambulance" aria-hidden="true" title="Copy to use ambulance"></i> fa-ambulance
									</div>
									<div class="col-md-4 col-sm-6 col-lg-3">
										<i class="fa fa-fw fa-american-sign-language-interpreting" aria-hidden="true" title="Copy to use american-sign-language-interpreting"></i> fa-american-sign-language-interpreting
									</div>
									<div class="col-md-4 col-sm-6 col-lg-3">
										<i class="fa fa-fw fa-anchor" aria-hidden="true" title="Copy to use anchor"></i> fa-anchor
									</div>
									<div class="col-md-4 col-sm-6 col-lg-3">
										<i class="fa fa-fw fa-android" aria-hidden="true" title="Copy to use android"></i> fa-android
									</div>
									<div class="col-md-4 col-sm-6 col-lg-3">
										<i class="fa fa-fw fa-angellist" aria-hidden="true" title="Copy to use angellist"></i> fa-angellist
									</div>
									<div class="col-md-4 col-sm-6 col-lg-3">
										<i class="fa fa-fw fa-angle-double-down" aria-hidden="true" title="Copy to use angle-double-down"></i> fa-angle-double-down
									</div>
									<div class="col-md-4 col-sm-6 col-lg-3">
										<i class="fa fa-fw fa-angle-double-left" aria-hidden="true" title="Copy to use angle-double-left"></i> fa-angle-double-left
									</div>
									<div class="col-md-4 col-sm-6 col-lg-3">
										<i class="fa fa-fw fa-angle-double-right" aria-hidden="true" title="Copy to use angle-double-right"></i> fa-angle-double-right
									</div>
									<div class="col-md-4 col-sm-6 col-lg-3">
										<i class="fa fa-fw fa-angle-double-up" aria-hidden="true" title="Copy to use angle-double-up"></i> fa-angle-double-up
									</div>
									<div class="col-md-4 col-sm-6 col-lg-3">
										<i class="fa fa-fw fa-angle-down" aria-hidden="true" title="Copy to use angle-down"></i> fa-angle-down
									</div>
									<div class="col-md-4 col-sm-6 col-lg-3">
										<i class="fa fa-fw fa-angle-left" aria-hidden="true" title="Copy to use angle-left"></i> fa-angle-left
									</div>
									<div class="col-md-4 col-sm-6 col-lg-3">
										<i class="fa fa-fw fa-angle-right" aria-hidden="true" title="Copy to use angle-right"></i> fa-angle-right
									</div>
									<div class="col-md-4 col-sm-6 col-lg-3">
										<i class="fa fa-fw fa-angle-up" aria-hidden="true" title="Copy to use angle-up"></i> fa-angle-up
									</div>
									<div class="col-md-4 col-sm-6 col-lg-3">
										<i class="fa fa-fw fa-apple" aria-hidden="true" title="Copy to use apple"></i> fa-apple
									</div>
									<div class="col-md-4 col-sm-6 col-lg-3">
										<i class="fa fa-fw fa-archive" aria-hidden="true" title="Copy to use archive"></i> fa-archive
									</div>
									<div class="col-md-4 col-sm-6 col-lg-3">
										<i class="fa fa-fw fa-area-chart" aria-hidden="true" title="Copy to use area-chart"></i> fa-area-chart
									</div>
									<div class="col-md-4 col-sm-6 col-lg-3">
										<i class="fa fa-fw fa-arrow-circle-down" aria-hidden="true" title="Copy to use arrow-circle-down"></i> fa-arrow-circle-down
									</div>
									<div class="clearfix"></div>
								</div>
								<div class="get-icon">
									<a target="_blank" href="http://fontawesome.io/icons/">Get the full list icons</a>
								</div>
								<h1 class="title-font">
									<span class="bg-cys">V2</span>Glyphicons</h1>
								<hr>
								<div class="row">
									<ul class=bs-glyphicons-list>
										<li>
											<span class="glyphicon glyphicon-asterisk" aria-hidden=true></span>
											<span class=glyphicon-class>glyphicon glyphicon-asterisk</span>
										</li>
										<li>
											<span class="glyphicon glyphicon-plus" aria-hidden=true></span>
											<span class=glyphicon-class>glyphicon glyphicon-plus</span>
										</li>
										<li>
											<span class="glyphicon glyphicon-euro" aria-hidden=true></span>
											<span class=glyphicon-class>glyphicon glyphicon-euro</span>
										</li>
										<li>
											<span class="glyphicon glyphicon-eur" aria-hidden=true></span>
											<span class=glyphicon-class>glyphicon glyphicon-eur</span>
										</li>
										<li>
											<span class="glyphicon glyphicon-minus" aria-hidden=true></span>
											<span class=glyphicon-class>glyphicon glyphicon-minus</span>
										</li>
										<li>
											<span class="glyphicon glyphicon-cloud" aria-hidden=true></span>
											<span class=glyphicon-class>glyphicon glyphicon-cloud</span>
										</li>
										<li>
											<span class="glyphicon glyphicon-envelope" aria-hidden=true></span>
											<span class=glyphicon-class>glyphicon glyphicon-envelope</span>
										</li>
										<li>
											<span class="glyphicon glyphicon-pencil" aria-hidden=true></span>
											<span class=glyphicon-class>glyphicon glyphicon-pencil</span>
										</li>
										<li>
											<span class="glyphicon glyphicon-glass" aria-hidden=true></span>
											<span class=glyphicon-class>glyphicon glyphicon-glass</span>
										</li>
										<li>
											<span class="glyphicon glyphicon-music" aria-hidden=true></span>
											<span class=glyphicon-class>glyphicon glyphicon-music</span>
										</li>
										<li>
											<span class="glyphicon glyphicon-search" aria-hidden=true></span>
											<span class=glyphicon-class>glyphicon glyphicon-search</span>
										</li>
										<li>
											<span class="glyphicon glyphicon-heart" aria-hidden=true></span>
											<span class=glyphicon-class>glyphicon glyphicon-heart</span>
										</li>
										<li>
											<span class="glyphicon glyphicon-star" aria-hidden=true></span>
											<span class=glyphicon-class>glyphicon glyphicon-star</span>
										</li>
										<li>
											<span class="glyphicon glyphicon-star-empty" aria-hidden=true></span>
											<span class=glyphicon-class>glyphicon glyphicon-star-empty</span>
										</li>
										<li>
											<span class="glyphicon glyphicon-user" aria-hidden=true></span>
											<span class=glyphicon-class>glyphicon glyphicon-user</span>
										</li>
										<li>
											<span class="glyphicon glyphicon-film" aria-hidden=true></span>
											<span class=glyphicon-class>glyphicon glyphicon-film</span>
										</li>
										<li>
											<span class="glyphicon glyphicon-th-large" aria-hidden=true></span>
											<span class=glyphicon-class>glyphicon glyphicon-th-large</span>
										</li>
										<li>
											<span class="glyphicon glyphicon-th" aria-hidden=true></span>
											<span class=glyphicon-class>glyphicon glyphicon-th</span>
										</li>
									</ul>
								</div>
								<div class="get-icon">
									<a target="_blank" href="http://getbootstrap.com/components/#glyphicons">Get the full list icons</a>
								</div>
								<hr>
								<!-- Custom Style -->
								<div class="c-styles">
									<span class="fa fa-database circle-icon"></span>
									<span class="fa fa-server square-icon"></span>
									<span class="fa fa-group border-icon"></span>
									<span class="fa fa-cog rotate-icon fa-spin"></span>
								</div>
							</div>
						</div>

						<!-- Image Frames -->
						<div id="i-frame" class="code-box">
							<div class="block-code">
								<div class="row">
									<div class="col-lg-4">
										<img src="assets/img/blog/1.jpg" width="249" alt="X-Data" class="img-rounded">
									</div>
									<div class="col-lg-4">
										<img src="assets/img/blog/2.jpg" width="249" alt="X-Data" class="img-circle">
									</div>
									<div class="col-lg-4">
										<img src="assets/img/blog/3.jpg" width="249" alt="X-Data" class="img-thumbnail">
									</div>
								</div>
								<hr>
								<img src="assets/img/blog/3.jpg" alt="X-Data" class="img-shadow">
							</div>
						</div>

						<!-- Pricing Tables -->
						<div id="p-tables" class="code-box">
							<div class="block-code">
								<img src="assets/img/shortcode.jpg" alt="X-Data" class="img-shadow">
								<div class="x-data-alert">
									<span class="fa fa-star x-icon"></span>
									<a target="_blank" class="plans-price-s" href="plans.html">Price Tables Here</a>
								</div>
							</div>
						</div>

						<!-- Accordion & Toggle -->
						<div id="acc-tog" class="code-box no-marg">
							<div class="block-code">
								<div class="panel-group custom" id="accordion">
									<!-- Faq #1 -->
									<div class="panel custom">
										<div class="panel-heading custom" role="tab" id="headingOne">
											<h4 class="panel-title custom">
												<a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
													How do I cancel and delete my account?
													<span class="fa fa-plus-circle coll-a"></span>
												</a>
											</h4>
										</div>
										<div id="collapseOne" class="panel-collapse collapse show custom" aria-labelledby="headingOne" data-parent="#accordion">
											<div class="panel-body custom">
												Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy
												text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen
												book.
											</div>
										</div>
									</div>
									<!-- Faq #2 -->
									<div class="panel custom">
										<div class="panel-heading custom" role="tab" id="headingTwo">
											<h4 class="panel-title custom">
												<a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo" aria-expanded="true" aria-controls="collapseTwo">
													Can I get my website listed in Google?
													<span class="fa fa-plus-circle coll-a"></span>
												</a>
											</h4>
										</div>
										<div id="collapseTwo" class="panel-collapse collapse custom" aria-labelledby="headingTwo" data-parent="#accordion">
											<div class="panel-body custom">
												Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy
												text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen
												book.
											</div>
										</div>
									</div>
									<!-- Faq #3 -->
									<div class="panel custom">
										<div class="panel-heading custom" role="tab" id="headingThree">
											<h4 class="panel-title custom">
												<a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseThree" aria-expanded="true" aria-controls="collapseThree">
													Can I run a business?
													<span class="fa fa-plus-circle coll-a"></span>
												</a>
											</h4>
										</div>
										<div id="collapseThree" class="panel-collapse collapse custom" aria-labelledby="headingThree" data-parent="#accordion">
											<div class="panel-body custom">
												Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy
												text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen
												book.
											</div>
										</div>
									</div>
									<!-- Faq #4 -->
									<div class="panel custom">
										<div class="panel-heading custom" role="tab" id="headingFour">
											<h4 class="panel-title custom">
												<a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseFour" aria-expanded="true" aria-controls="collapseFour">
													Can I create new pages?
													<span class="fa fa-plus-circle coll-a"></span>
												</a>
											</h4>
										</div>
										<div id="collapseFour" class="panel-collapse collapse custom" aria-labelledby="headingFour" data-parent="#accordion">
											<div class="panel-body custom">
												Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy
												text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen
												book.
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>

		<div class="clearfix"></div>

		<?php $this->load->view('sub-page/footer'); ?>
	</div>

	<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
	<script src="assets/js/jquery-2.2.4.min.js"></script>
	<!-- Include all compiled plugins (below), or include individual files as needed -->
	<script src="assets/js/popper.min.js"></script>
	<script src="assets/js/bootstrap.min.js"></script>
	<!-- Owl Carousel -->
	<script src="assets/js/owl.carousel.min.js"></script>
	<!-- Plugins -->
	<script src="assets/js/plugins.js"></script>

</body>

</html>
