<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<footer class="footer">
			<!-- Contact -->
			<div class="contact" id="contacts">
				<!-- Map -->
				<div class="map">
					<span class="fa fa-map-marker cont"></span>
					<span>J.P. Rizal Ext, Makati, 1215 Metro Manila</span>
				</div>
				<!-- Phone -->
				<div class="phone">
					<span class="fa fa-phone cont"></span>
					<span>+(02) 8883 1860</span>
				</div>
				<!-- Mail -->
				<div class="mail">
					<span class="fa fa-envelope cont"></span>
					<a href="mailto:ufro@umak.edu.ph" target="_top">ufro@umak.edu.ph</a>
				</div>
				<!-- Live Chat -->
				<div class="l-chat">
					<span class="fa fa-headphones cont"></span>
					<a href="#">Message us</a>
				</div>
			</div>
			<!-- Footer Lv2 -->
			<div class="f-lv2">
				<div class="container" >
					<div class="row">
						<!-- About -->
						<div class="col-lg-6 col-sm-3">
							<div class="about">
								<!-- Brand -->
								<img src="assets/img/logo-b.png" style="height: 50px;" alt="X-Data">
								<!-- iNFO -->
								<p>
									Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy
									text ever since the 1500s .
								</p>
								<!-- Links -->
								<a href="terms">Terms |</a>
								<a href="terms">Policy |</a>
								<a href="contact">Careers</a>
								<!-- CopyRights -->
								<h4>© 2021 University of Makaty. All rights reserved.</h4>
							</div>
						</div>
						<!-- Help -->
						<div class="col-lg-2 col-sm-3">
							<div class="links-foot">
								<h2>Help</h2>
								<ul>
									<li>
										<a href="#">Chat us</a>
									</li>
									<li>
										<a href="faq">Faq</a>
									</li>
									<li>
										<a href="#contacts">Contact</a>
									</li>
								</ul>
							</div>
						</div>
						<!-- NewsLetter -->
						<div class="col-lg-4 col-sm-3">
							<div class="links-foot">
								<h2>NewsLetter</h2>
								<p>
									Lorem Ipsum is simply dummy text of the printing and typesetting industry.
								</p>
								<input class="email-news" type="email" placeholder="email">
								<input class="sub-news" type="submit" value="Subscribe">
							</div>
						</div>
					</div>
				</div>
			</div>
		</footer>