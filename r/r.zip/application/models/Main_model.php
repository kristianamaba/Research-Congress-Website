<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Main_model extends CI_Model {
  
	public function __construct(){
	parent::__construct();

	// Load base_url 
	$this->load->helper('url');
	}

}
?>